import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import API from './API'
import Validate from './validation'
import Lifecycle from './Lifecycle'
import './index.css'



function tick() {
	const header = (
		<div>
			<h1><center>Jitendra Dariwal</center></h1>
			<h2>It is {new Date().toLocaleTimeString()}.</h2>
		</div>
	);
	ReactDOM.render(header, document.getElementById('main'))
}

setInterval(tick, 1000);

ReactDOM.render(<App />, document.getElementById('root'))
ReactDOM.render(<API />, document.getElementById('API'))


function Welcome(props) {
	return <h1>Hello, {props.name}</h1>;
}

function Multi() {
  return (
    <div>
      <Welcome name="Sara" />
      <Welcome name="Cahal" />
      <Welcome name="Edite" />
    </div>
  );
}

const element = <Multi />;
ReactDOM.render(
  element,
  document.getElementById('test')
);


ReactDOM.render(<Validate />, document.getElementById('validation'))
ReactDOM.render(<Lifecycle />, document.getElementById('lifecycle'))