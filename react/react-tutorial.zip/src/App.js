import React, { Component } from 'react'
import Table from './Table'
import Form from './Form';

class App extends Component {
	
	state = {
		characters : []
	}
																			
	removeCharacter = index => {
		const { characters } = this.state

		this.setState({
			characters: characters.filter((character, i) => {
				return i !== index
			}),
		})
	}
	
    handleSubmit = character => {
        this.setState({characters: [...this.state.characters, character]});
    }
	
	render() {
		/* const url = 'http://192.168.5.109:3002/api/get_profile_info/PROF10003?business_id=BUZNID1'

		fetch(url).then(result => result.json()).then(result => {
			console.log("result : ", result)
		}) */
		
		const { characters } = this.state
		
		return (
			<div className="container">
				<Table rowDatas = {characters} removeCharacter = {this.removeCharacter} />
				<Form handleSubmit={this.handleSubmit} />
			</div>
		)
	}
}

export default App