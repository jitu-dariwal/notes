const _MODULE_VERSION_ = '0.0.13';

export function getVersion(): string {
    return _MODULE_VERSION_;
}
