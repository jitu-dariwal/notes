export const specialCharacters = [')', '!', '@', '#', '$', '%', '^', '&', 'x', '('];
export const supportedCharacters = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 'x', '*', '/', '.', '+', '-', '%', '^', '(', ')'];
