# JQuery-expression-builder
JQuery plugin offering an interface to create arithmetic expressions

JQuery Expression Builder is UI component to create a input for arithmetic expressions with functiuons and intellisense.

Website: https://exp.js.org
CodePen: https://codepen.io/magicops/pen/yRgQwV/

```
    _______  __ ____         _______
   / ____/ |/ // __ \       / / ___/
  / __/  |   // /_/ /  __  / /\__ \ 
 / /___ /   |/ ____/  / /_/ /___/ / 
/_____//_/|_/_/       \____//____/  
```
