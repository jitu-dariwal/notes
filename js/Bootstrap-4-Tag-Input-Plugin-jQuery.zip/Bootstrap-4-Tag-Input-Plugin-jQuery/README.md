# Bootstrap Tags Input
Bootstrap Tags Input is a jQuery plugin providing a Twitter Bootstrap user interface for managing tags.


## Usage
Examples can be found [here](http://bootstrap-tagsinput.github.io/bootstrap-tagsinput/examples/).

## Features
* Objects as tags
* True multi value
* Typeahead
* Modified for Bootstrap 4 Alpha

## Unmantained code AS-IS
If you need this plugin please fork and continue development, as I only needed it for a single project and will not continue further maintenance :)
